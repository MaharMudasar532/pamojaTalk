
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import { getDatabase, ref, onValue, set, get, onChildAdded, child, update, onChildChanged } from "firebase/database";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../../firebase"


export const listenForNewSosWithNotification = () => {
    const db = getDatabase();
    const usersRef = ref(db, 'users');
  
    onChildChanged(usersRef, (snapshot) => {
      const user = snapshot.val();
      const { userName } = user;
  
      if (user.SOS) {
        const sosData = user.SOS;
  
        for (const sosId in sosData) {
          const sosItem = sosData[sosId];
  
          if (!sosItem.isRead) {
            // Show a notification for the new unread SOS
            // toast.warning(`${userName} Needs Emergency Help`, { autoClose: 3000 });
  
            // Mark the SOS as read
            const sosRef = child(ref(db, `users/${user.uid}/SOS`), sosId);
            update(sosRef, { isRead: true });
          }
        }
      }
    });
  };
  